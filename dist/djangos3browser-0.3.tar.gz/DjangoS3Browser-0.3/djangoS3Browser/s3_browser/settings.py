STATIC_URL = '/static/'
STATIC_ROOT = '/static/'

